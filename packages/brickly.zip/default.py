# speed = 90
# highlightBlock('2hV08jyWqDBe^7e5uY.f')
print('Hallo TXT!')
# highlightBlock('MCRNj*tar6rGl4..a5Y{')
setOutput(0, (100))
# highlightBlock('8/BOeX[riW53/8v^}0=z')
wait(1)
# highlightBlock('i?[$;E{qI^82hPQ^*j0/')
setOutput(0, (0))
