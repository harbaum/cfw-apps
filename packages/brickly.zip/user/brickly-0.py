# speed = 90
# highlightBlock('.;vUh%UjB3il^8YTe9jv')
print('Hello Brickly!')
