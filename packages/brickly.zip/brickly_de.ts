<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE" sourcelanguage="en_US">
<context>
    <name>Menu</name>
    <message>
        <location filename="brickly_app.py" line="475"/>
        <source>Run...</source>
        <translation>Los...</translation>
    </message>
    <message>
        <location filename="brickly_app.py" line="479"/>
        <source>Stop!</source>
        <translation>Stopp!</translation>
    </message>
</context>
</TS>
