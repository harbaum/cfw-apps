<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE" sourcelanguage="en_US">
<context>
    <name>Menu</name>
    <message>
        <location filename="brickly_app.py" line="576"/>
        <source>Run...</source>
        <translation type="obsolete">Los...</translation>
    </message>
    <message>
        <location filename="brickly_app.py" line="586"/>
        <source>Stop!</source>
        <translation>Stopp!</translation>
    </message>
    <message>
        <location filename="brickly_app.py" line="576"/>
        <source>Run</source>
        <translation>Los</translation>
    </message>
    <message>
        <location filename="brickly_app.py" line="484"/>
        <source>Select...</source>
        <translation>Auswahl...</translation>
    </message>
</context>
<context>
    <name>Selection</name>
    <message>
        <location filename="brickly_app.py" line="443"/>
        <source>Program</source>
        <translation>Programm</translation>
    </message>
</context>
</TS>
