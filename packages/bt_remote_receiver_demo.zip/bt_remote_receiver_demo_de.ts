<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>Input</name>
    <message>
        <location filename="bt_remote_receiver_demo.py" line="194"/>
        <source>Battery</source>
        <translation>Batterie</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="bt_remote_receiver_demo.py" line="227"/>
        <source>BT remote</source>
        <translation>BT-Remote</translation>
    </message>
</context>
<context>
    <name>Scanner</name>
    <message>
        <location filename="bt_remote_receiver_demo.py" line="41"/>
        <source>Searching for BT remote receiver.</source>
        <translation>Suche nach BT-Remote-Empfänger.</translation>
    </message>
    <message>
        <location filename="bt_remote_receiver_demo.py" line="69"/>
        <source>Connecting to BT remote receiver.</source>
        <translation>Verbinde mit BT-Remote-Empfänger.</translation>
    </message>
</context>
</TS>
