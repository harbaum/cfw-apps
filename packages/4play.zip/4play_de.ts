<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de" sourcelanguage="en">
<context>
    <name>main</name>
    <message>
        <location filename="4play.py" line="388"/>
        <source>4Play</source>
        <translation>4Spiel</translation>
    </message>
</context>
<context>
    <name>menu</name>
    <message>
        <location filename="4play.py" line="392"/>
        <source>New</source>
        <translation>Neu</translation>
    </message>
</context>
<context>
    <name>result</name>
    <message>
        <location filename="4play.py" line="367"/>
        <source>your turn ...</source>
        <translation>Dein Zug...</translation>
    </message>
    <message>
        <location filename="4play.py" line="365"/>
        <source>thinking ...</source>
        <translation>denke ...</translation>
    </message>
    <message>
        <location filename="4play.py" line="370"/>
        <source>You win</source>
        <translation>Du gewinnst</translation>
    </message>
    <message>
        <location filename="4play.py" line="372"/>
        <source>Tie</source>
        <translation>Gleichstand</translation>
    </message>
    <message>
        <location filename="4play.py" line="374"/>
        <source>You loose</source>
        <translation>Du verlierst</translation>
    </message>
</context>
</TS>
