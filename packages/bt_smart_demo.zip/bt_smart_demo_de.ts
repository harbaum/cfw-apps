<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>Input</name>
    <message>
        <location filename="bt_smart_demo.py" line="194"/>
        <source>Battery</source>
        <translation>Batterie</translation>
    </message>
    <message>
        <location filename="bt_smart_demo.py" line="160"/>
        <source>open</source>
        <translation>offen</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="bt_smart_demo.py" line="227"/>
        <source>BT smart</source>
        <translation>BT-Smart</translation>
    </message>
</context>
<context>
    <name>Scanner</name>
    <message>
        <location filename="bt_smart_demo.py" line="41"/>
        <source>Searching for BT smart controller.</source>
        <translation>Suche nach BT-Smart-Controller.</translation>
    </message>
    <message>
        <location filename="bt_smart_demo.py" line="69"/>
        <source>Connecting to BT smart controller.</source>
        <translation>Verbinde mit BT-Smart-Controller.</translation>
    </message>
</context>
</TS>
