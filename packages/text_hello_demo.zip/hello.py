print("Hello World!");
a = 12 + 13
print("12 + 13 is", a);

print("")
print("You can replace hello.py with any simple python3 script you like.")
print("You can even rename it.")
print("")
print("Don't forget to change the UUID in the manifest file if you plan")
print("to distribute your program.")
